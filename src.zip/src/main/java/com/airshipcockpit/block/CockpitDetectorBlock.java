package com.airshipcockpit.block;

import org.jetbrains.annotations.Nullable;
import com.airshipcockpit.blockentity.CockpitDetectorBlockEntity;
import com.airshipcockpit.blockentity.CockpitScreenBlockEntity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;

public class CockpitDetectorBlock extends Block implements EntityBlock {

    public static final BooleanProperty POWERED  = BlockStateProperties.POWERED;
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;

    public CockpitDetectorBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(
            this.stateDefinition.any()
                .setValue(POWERED, false)
                .setValue(FACING, Direction.NORTH)
        );
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(POWERED, FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return this.defaultBlockState()
            .setValue(FACING, ctx.getHorizontalDirection())
            .setValue(POWERED, false);
    }

    @Override
    @Nullable
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CockpitDetectorBlockEntity(pos, state);
    }

    @Override
    protected void neighborChanged(
            BlockState state, Level level, BlockPos pos,
            Block block, BlockPos neighborPos, boolean movedByPiston) {

        if (!level.isClientSide) {
            boolean powered = level.hasNeighborSignal(pos);
            if (powered != state.getValue(POWERED)) {
                level.setBlock(pos, state.setValue(POWERED, powered), 3);
                if (level.getBlockEntity(pos) instanceof CockpitDetectorBlockEntity detBE) {
                    BlockPos screenPos = detBE.getLinkedScreen();
                    if (screenPos != null &&
                        level.getBlockEntity(screenPos) instanceof CockpitScreenBlockEntity screenBE) {
                        screenBE.setActive(powered);
                    }
                }
            }
        }
    }

    @Override
    protected InteractionResult useWithoutItem(
            BlockState state, Level level, BlockPos pos,
            Player player, BlockHitResult hit) {

        if (!level.isClientSide) {
            CompoundTag data = player.getPersistentData();
            data.putInt("CockpitDetectorX", pos.getX());
            data.putInt("CockpitDetectorY", pos.getY());
            data.putInt("CockpitDetectorZ", pos.getZ());
            player.sendSystemMessage(Component.literal(
                "§a已选中检测器 " + pos.toShortString() +
                " 朝向:" + state.getValue(FACING).getName() + "，右键屏幕完成绑定"));
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
