package com.airshipcockpit.block;

import org.jetbrains.annotations.Nullable;
import com.airshipcockpit.blockentity.CockpitScreenBlockEntity;
import com.airshipcockpit.blockentity.CockpitDetectorBlockEntity;
import com.airshipcockpit.AirshipCockpitMod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;

public class CockpitScreenBlock extends Block implements EntityBlock {

    public static final BooleanProperty   POWERED = BlockStateProperties.POWERED;
    public static final DirectionProperty FACING  = BlockStateProperties.HORIZONTAL_FACING;

    public CockpitScreenBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(
            this.stateDefinition.any()
                .setValue(POWERED, false)
                .setValue(FACING, Direction.NORTH)
        );
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(POWERED, FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return this.defaultBlockState()
            .setValue(FACING, ctx.getHorizontalDirection().getOpposite())
            .setValue(POWERED, false);
    }

    @Override
    @Nullable
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CockpitScreenBlockEntity(pos, state);
    }

    @Override
    protected void neighborChanged(
            BlockState state, Level level, BlockPos pos,
            Block block, BlockPos neighborPos, boolean movedByPiston) {

        if (!level.isClientSide) {
            boolean signal    = level.hasNeighborSignal(pos);
            boolean wasPowered = state.getValue(POWERED);
            if (signal != wasPowered) {
                // 只改 BlockState 的 POWERED，不干扰 BE 的 active
                level.setBlock(pos, state.setValue(POWERED, signal), 2);
                if (level.getBlockEntity(pos) instanceof CockpitScreenBlockEntity be) {
                    be.setActive(signal);
                }
            }
        }
    }

    @Override
    protected InteractionResult useWithoutItem(
            BlockState state, Level level, BlockPos pos,
            Player player, BlockHitResult hit) {

        if (!level.isClientSide) {
            // 潜行右键：只改 BE 的 active，完全不碰 BlockState，避免触发 neighborChanged
            if (player.isShiftKeyDown()) {
                if (level.getBlockEntity(pos) instanceof CockpitScreenBlockEntity be) {
                    boolean newState = !be.isActive();
                    be.setActive(newState);
                    player.sendSystemMessage(Component.literal(
                        "§e[调试] 屏幕切换为: " + (newState ? "§a激活" : "§c关闭")));
                }
                return InteractionResult.SUCCESS;
            }

            // 普通右键：绑定检测器
            CompoundTag data = player.getPersistentData();
            if (!data.contains("CockpitDetectorX")) {
                player.sendSystemMessage(Component.literal("§c请先右键选中一个检测器"));
                return InteractionResult.FAIL;
            }
            BlockPos detectorPos = new BlockPos(
                data.getInt("CockpitDetectorX"),
                data.getInt("CockpitDetectorY"),
                data.getInt("CockpitDetectorZ")
            );
            if (level.getBlockEntity(pos) instanceof CockpitScreenBlockEntity screenBE) {
                screenBE.setLinkedDetector(detectorPos);
            }
            if (level.getBlockEntity(detectorPos) instanceof CockpitDetectorBlockEntity detectorBE) {
                detectorBE.setLinkedScreen(pos);
            }
            player.sendSystemMessage(Component.literal(
                "§a绑定成功！" + detectorPos.toShortString() + " → " + pos.toShortString()));
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
