
package com.airshipcockpit.blockentity;

import com.airshipcockpit.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CockpitScreenBlockEntity extends BlockEntity {

    private BlockPos linkedDetector;
    private BlockPos controllerPos;
    private boolean active = false;

    private BlockPos groupMinPos = BlockPos.ZERO;
    private BlockPos groupMaxPos = BlockPos.ZERO;
    private int groupWidth  = 1;
    private int groupHeight = 1;

    public CockpitScreenBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.COCKPIT_SCREEN.get(), pos, state);
    }

    public void setLinkedDetector(BlockPos pos) {
        this.linkedDetector = pos;
        recalculateMultiBlockGroup();
        setChanged();
        syncToClient();
    }

    public BlockPos getLinkedDetector() { return this.linkedDetector; }

    public void setControllerPos(BlockPos pos) {
        this.controllerPos = pos;
        setChanged();
        syncToClient();
    }

    public BlockPos getControllerPos() {
        return this.controllerPos != null ? this.controllerPos : this.getBlockPos();
    }

    public void setActive(boolean active) {
        if (this.active == active) return;
        this.active = active;
        setChanged();
        syncToClient();
        if (this.level != null && !this.level.isClientSide) {
            propagateActiveToGroup(active);
        }
    }

    public boolean isActive() { return this.active; }

    // 根据屏幕朝向决定 UV 轴：NORTH/SOUTH 用 X，EAST/WEST 用 Z
    public float[] getGroupUVOffsets(Direction facing) {
        BlockPos myPos = this.getBlockPos();

        float uMin, uMax;
        if (facing == Direction.EAST || facing == Direction.WEST) {
            int zOffset = myPos.getZ() - groupMinPos.getZ();
            int zRange  = Math.max(1, groupMaxPos.getZ() - groupMinPos.getZ() + 1);
            // WEST 需要镜像 U 轴
            if (facing == Direction.WEST) {
                uMin = (float)(zRange - zOffset - 1) / (float)zRange;
                uMax = (float)(zRange - zOffset)     / (float)zRange;
            } else {
                uMin = (float)zOffset         / (float)zRange;
                uMax = (float)(zOffset + 1)   / (float)zRange;
            }
        } else {
            int xOffset = myPos.getX() - groupMinPos.getX();
            int xRange  = Math.max(1, groupMaxPos.getX() - groupMinPos.getX() + 1);
            // SOUTH 需要镜像 U 轴
            if (facing == Direction.SOUTH) {
                uMin = (float)(xRange - xOffset - 1) / (float)xRange;
                uMax = (float)(xRange - xOffset)     / (float)xRange;
            } else {
                uMin = (float)xOffset         / (float)xRange;
                uMax = (float)(xOffset + 1)   / (float)xRange;
            }
        }

         int yOffset = myPos.getY() - groupMinPos.getY();
         float vMin = 1.0f - ((float)(yOffset + 1) / (float)groupHeight);
         float vMax = 1.0f - ((float)yOffset       / (float)groupHeight);

        return new float[]{uMin, uMax, vMin, vMax};
    }

    public void recalculateMultiBlockGroup() {
        if (this.level == null) return;

        Set<BlockPos>  visited = new HashSet<>();
        List<BlockPos> queue   = new ArrayList<>();
        queue.add(this.getBlockPos());
        visited.add(this.getBlockPos());

        int minX = this.worldPosition.getX(), maxX = minX;
        int minY = this.worldPosition.getY(), maxY = minY;
        int minZ = this.worldPosition.getZ(), maxZ = minZ;

        int head = 0;
        while (head < queue.size()) {
            BlockPos cur = queue.get(head++);
            for (BlockPos nb : new BlockPos[]{
                    cur.above(), cur.below(),
                    cur.north(), cur.south(),
                    cur.east(),  cur.west()}) {
                if (!visited.contains(nb) &&
                    this.level.getBlockEntity(nb) instanceof CockpitScreenBlockEntity) {
                    visited.add(nb);
                    queue.add(nb);
                    minX = Math.min(minX, nb.getX()); maxX = Math.max(maxX, nb.getX());
                    minY = Math.min(minY, nb.getY()); maxY = Math.max(maxY, nb.getY());
                    minZ = Math.min(minZ, nb.getZ()); maxZ = Math.max(maxZ, nb.getZ());
                }
            }
        }

        this.groupMinPos = new BlockPos(minX, minY, minZ);
        this.groupMaxPos = new BlockPos(maxX, maxY, maxZ);
        this.groupWidth  = Math.max(1, maxX - minX + 1);
        this.groupHeight = Math.max(1, maxY - minY + 1);

        for (BlockPos pos : visited) {
            if (this.level.getBlockEntity(pos) instanceof CockpitScreenBlockEntity be && be != this) {
                be.groupMinPos    = this.groupMinPos;
                be.groupMaxPos    = this.groupMaxPos;
                be.groupWidth     = this.groupWidth;
                be.groupHeight    = this.groupHeight;
                be.linkedDetector = this.linkedDetector;
                be.active         = this.active;
                be.setChanged();
                be.syncToClient();
            }
        }
    }

    private void propagateActiveToGroup(boolean active) {
        for (int x = groupMinPos.getX(); x <= groupMaxPos.getX(); x++) {
            for (int y = groupMinPos.getY(); y <= groupMaxPos.getY(); y++) {
                for (int z = groupMinPos.getZ(); z <= groupMaxPos.getZ(); z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    if (!pos.equals(this.worldPosition) &&
                        this.level.getBlockEntity(pos) instanceof CockpitScreenBlockEntity be) {
                        be.active = active;
                        be.setChanged();
                        be.syncToClient();
                    }
                }
            }
        }
    }

    private void syncToClient() {
        if (this.level != null && !this.level.isClientSide) {
            this.level.sendBlockUpdated(
                this.getBlockPos(), this.getBlockState(), this.getBlockState(), 3);
        }
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider provider) { return saveWithoutMetadata(provider); }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() { return ClientboundBlockEntityDataPacket.create(this); }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider provider) {
        super.saveAdditional(tag, provider);
        tag.putBoolean("Active", this.active);
        tag.putInt("GMinX", groupMinPos.getX()); tag.putInt("GMinY", groupMinPos.getY()); tag.putInt("GMinZ", groupMinPos.getZ());
        tag.putInt("GMaxX", groupMaxPos.getX()); tag.putInt("GMaxY", groupMaxPos.getY()); tag.putInt("GMaxZ", groupMaxPos.getZ());
        tag.putInt("GWidth", groupWidth); tag.putInt("GHeight", groupHeight);
        if (this.linkedDetector != null) {
            tag.putInt("DetectorX", this.linkedDetector.getX());
            tag.putInt("DetectorY", this.linkedDetector.getY());
            tag.putInt("DetectorZ", this.linkedDetector.getZ());
        }
        if (this.controllerPos != null) {
            tag.putInt("ControllerX", this.controllerPos.getX());
            tag.putInt("ControllerY", this.controllerPos.getY());
            tag.putInt("ControllerZ", this.controllerPos.getZ());
        }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider provider) {
        super.loadAdditional(tag, provider);
        this.active       = tag.getBoolean("Active");
        this.groupMinPos  = new BlockPos(tag.getInt("GMinX"), tag.getInt("GMinY"), tag.getInt("GMinZ"));
        this.groupMaxPos  = new BlockPos(tag.getInt("GMaxX"), tag.getInt("GMaxY"), tag.getInt("GMaxZ"));
        this.groupWidth   = Math.max(1, tag.getInt("GWidth"));
        this.groupHeight  = Math.max(1, tag.getInt("GHeight"));
        if (tag.contains("DetectorX")) {
            this.linkedDetector = new BlockPos(
                tag.getInt("DetectorX"), tag.getInt("DetectorY"), tag.getInt("DetectorZ"));
        }
        if (tag.contains("ControllerX")) {
            this.controllerPos = new BlockPos(
                tag.getInt("ControllerX"), tag.getInt("ControllerY"), tag.getInt("ControllerZ"));
        }
    }
}
