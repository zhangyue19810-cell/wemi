package com.airshipcockpit.blockentity;

import com.airshipcockpit.registry.ModBlockEntities;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class CockpitDetectorBlockEntity extends BlockEntity {

    private BlockPos linkedScreen;
    private int detectorIndex = 0;

    public CockpitDetectorBlockEntity(
            BlockPos pos,
            BlockState state) {

        super(
                ModBlockEntities.COCKPIT_DETECTOR.get(),
                pos,
                state
        );
    }

    public void setLinkedScreen(BlockPos pos) {
        linkedScreen = pos;
        setChanged();
    }

    public BlockPos getLinkedScreen() {
        return linkedScreen;
    }

    public void setDetectorIndex(int index) {
        detectorIndex = index;
        setChanged();
    }

    public int getDetectorIndex() {
        return detectorIndex;
    }

    @Override
    protected void saveAdditional(
            CompoundTag tag,
            HolderLookup.Provider provider) {

        super.saveAdditional(tag, provider);

        tag.putInt("DetectorIndex", detectorIndex);

        if (linkedScreen != null) {
            tag.putInt("ScreenX", linkedScreen.getX());
            tag.putInt("ScreenY", linkedScreen.getY());
            tag.putInt("ScreenZ", linkedScreen.getZ());
        }
    }

    @Override
    protected void loadAdditional(
            CompoundTag tag,
            HolderLookup.Provider provider) {

        super.loadAdditional(tag, provider);

        detectorIndex = tag.getInt("DetectorIndex");

        if (tag.contains("ScreenX")) {
            linkedScreen = new BlockPos(
                    tag.getInt("ScreenX"),
                    tag.getInt("ScreenY"),
                    tag.getInt("ScreenZ")
            );
        }
    }
}
