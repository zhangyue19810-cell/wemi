package com.airshipcockpit.registry;

import com.airshipcockpit.AirshipCockpitMod;
import com.airshipcockpit.blockentity.CockpitDetectorBlockEntity;
import com.airshipcockpit.blockentity.CockpitScreenBlockEntity;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;

import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlockEntities {

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, AirshipCockpitMod.MODID);

    public static final DeferredHolder<
            BlockEntityType<?>,
            BlockEntityType<CockpitDetectorBlockEntity>
            > COCKPIT_DETECTOR =
            BLOCK_ENTITIES.register(
                    "cockpit_detector",
                    () -> BlockEntityType.Builder.of(
                            CockpitDetectorBlockEntity::new,
                            AirshipCockpitMod.COCKPIT_DETECTOR.get()
                    ).build(null)
            );

    public static final DeferredHolder<
            BlockEntityType<?>,
            BlockEntityType<CockpitScreenBlockEntity>
            > COCKPIT_SCREEN =
            BLOCK_ENTITIES.register(
                    "cockpit_screen",
                    () -> BlockEntityType.Builder.of(
                            CockpitScreenBlockEntity::new,
                            AirshipCockpitMod.COCKPIT_SCREEN.get()
                    ).build(null)
            );
}
