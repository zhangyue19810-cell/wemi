package com.airshipcockpit;

import com.mojang.logging.LogUtils;
import com.airshipcockpit.block.CockpitDetectorBlock;
import com.airshipcockpit.block.CockpitScreenBlock;
import com.airshipcockpit.block.OrientationControllerBlock;
import com.airshipcockpit.item.CockpitLinkerItem;
import org.slf4j.Logger;
import com.airshipcockpit.registry.ModBlockEntities;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;

import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

@Mod(AirshipCockpitMod.MODID)
public class AirshipCockpitMod {

    public static final String MODID = "airshipcockpit";
    public static final Logger LOGGER = LogUtils.getLogger();                                       
    
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);                                                   
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    // ─── 方块与物品规范注册 (彻底消除重复注册缺陷) ─────────────────────────────────────
    public static final DeferredBlock<Block> COCKPIT_SCREEN =
            BLOCKS.register("cockpit_screen", () -> new CockpitScreenBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(2.0f)));
    public static final DeferredItem<Item> COCKPIT_SCREEN_ITEM =
            ITEMS.register("cockpit_screen", () -> new BlockItem(COCKPIT_SCREEN.get(), new Item.Properties()));

    public static final DeferredBlock<Block> COCKPIT_SLOPED_SCREEN =
            BLOCKS.registerSimpleBlock("cockpit_sloped_screen", BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(2.0f));
    // 【核心修正】放弃快捷方法，改用标准显式 BlockItem 注册，彻底击碎 MappedRegistry 闪退异常
    public static final DeferredItem<Item> COCKPIT_SLOPED_SCREEN_ITEM =
            ITEMS.register("cockpit_sloped_screen", () -> new BlockItem(COCKPIT_SLOPED_SCREEN.get(), new Item.Properties()));

    public static final DeferredBlock<Block> COCKPIT_DETECTOR =
            BLOCKS.register("cockpit_detector", () -> new CockpitDetectorBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(3.0f)));
    public static final DeferredItem<Item> COCKPIT_DETECTOR_ITEM =
            ITEMS.register("cockpit_detector", () -> new BlockItem(COCKPIT_DETECTOR.get(), new Item.Properties()));

    public static final DeferredBlock<Block> ORIENTATION_CONTROLLER =
            BLOCKS.register("orientation_controller", () -> new OrientationControllerBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLUE).strength(3.0f)));
    public static final DeferredItem<Item> ORIENTATION_CONTROLLER_ITEM =
            ITEMS.register("orientation_controller", () -> new BlockItem(ORIENTATION_CONTROLLER.get(), new Item.Properties()));

    // ─── 链路工具注册 ──────────────────────────────────────────
    public static final DeferredItem<Item> COCKPIT_LINKER =
            ITEMS.register("cockpit_linker", () -> new CockpitLinkerItem(new Item.Properties().stacksTo(1)));

    // ─── 创造模式背包栏 ──────────────────────────────────────────
    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> COCKPIT_TAB = 
            CREATIVE_TABS.register("cockpit_tab", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.airshipcockpit.tab"))
                    .icon(() -> COCKPIT_LINKER.get().getDefaultInstance())
                    .displayItems((parameters, output) -> {
                        output.accept(COCKPIT_LINKER.get());
                        output.accept(COCKPIT_SCREEN_ITEM.get());
                        output.accept(COCKPIT_SLOPED_SCREEN_ITEM.get());
                        output.accept(COCKPIT_DETECTOR_ITEM.get());
                        output.accept(ORIENTATION_CONTROLLER_ITEM.get());
                    })
                    .build()
            );

    public AirshipCockpitMod(IEventBus modEventBus, ModContainer modContainer) {
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        CREATIVE_TABS.register(modEventBus);
        
        ModBlockEntities.BLOCK_ENTITIES.register(modEventBus);
        modContainer.registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        LOGGER.info("Airship Cockpit System Registry Duplicate Fixed!");
    }
}
