package com.airshipcockpit.client;

import net.neoforged.fml.ModList;

public class RenderCompat {

    public static boolean isIrisLoaded() {
        return ModList.get().isLoaded("iris");
    }

    public static boolean isEmbeddiumLoaded() {
        return ModList.get().isLoaded("embeddium");
    }

    public static boolean useSafeMode() {
        return isIrisLoaded() || isEmbeddiumLoaded();
    }
}
