package com.airshipcockpit.client;

import com.mojang.blaze3d.pipeline.TextureTarget;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class CockpitRenderHandler {

    private static final Map<BlockPos, TextureTarget>    DETECTOR_FBOS       = new HashMap<>();
    private static final Map<BlockPos, FBOBackedTexture> BACKED_TEXTURES     = new HashMap<>();
    private static final Map<BlockPos, ResourceLocation> TEXTURE_LOCATIONS   = new HashMap<>();
    private static final Set<BlockPos>                   ACTIVE_DETECTORS    = new HashSet<>();

    private static long lastRenderTime = 0;
    private static final long FRAME_TIME_MS = 1000 / 60; // 60 FPS

    // ── 激活状态 ─────────────────────────────────────────────
    public static void setDetectorActive(BlockPos pos, boolean active) {
        if (active) ACTIVE_DETECTORS.add(pos);
        else        ACTIVE_DETECTORS.remove(pos);
    }

    public static Set<BlockPos> getActiveDetectors() {
        return new HashSet<>(ACTIVE_DETECTORS);
    }

    // ── FBO 管理 ──────────────────────────────────────────────
    public static TextureTarget getOrCreateFBO(BlockPos pos) {
        return DETECTOR_FBOS.computeIfAbsent(pos, p -> {
            TextureTarget fbo = new TextureTarget(1024, 1536, true, Minecraft.ON_OSX);
            fbo.setClearColor(0f, 0f, 0f, 1f);
            fbo.clear(Minecraft.ON_OSX);
            ensureTextureRegistered(p, fbo);
            return fbo;
        });
    }

    // 渲染完后把 FBO 颜色纹理 ID 同步给材质包装器
    public static void syncFBOTexture(BlockPos pos) {
        TextureTarget fbo = DETECTOR_FBOS.get(pos);
        FBOBackedTexture tex = BACKED_TEXTURES.get(pos);
        if (fbo != null && tex != null) {
            tex.updateId(fbo.getColorTextureId());
        }
    }

    // ── 纹理注册 ──────────────────────────────────────────────
    private static void ensureTextureRegistered(BlockPos pos, TextureTarget fbo) {
        if (TEXTURE_LOCATIONS.containsKey(pos)) return;
        Minecraft mc = Minecraft.getInstance();
        FBOBackedTexture tex = new FBOBackedTexture(fbo.getColorTextureId());
        ResourceLocation loc = ResourceLocation.fromNamespaceAndPath(
            "airshipcockpit",
            "dynamic/screen_" + Math.abs(pos.hashCode())
        );
        mc.getTextureManager().register(loc, tex);
        System.out.println("REGISTERED " + loc);
        BACKED_TEXTURES.put(pos, tex);
        TEXTURE_LOCATIONS.put(pos, loc);
    }

    public static ResourceLocation getTextureLocation(BlockPos pos) {
        return TEXTURE_LOCATIONS.get(pos);
    }

    // ── 帧率控制 ──────────────────────────────────────────────
    public static boolean shouldRenderThisFrame() {
        long now = System.currentTimeMillis();
        if (now - lastRenderTime >= FRAME_TIME_MS) {
            lastRenderTime = now;
            return true;
        }
        return false;
    }

    public static void cleanUp() {
        DETECTOR_FBOS.values().forEach(fbo -> fbo.destroyBuffers());
        DETECTOR_FBOS.clear();
        BACKED_TEXTURES.clear();
        TEXTURE_LOCATIONS.clear();
        ACTIVE_DETECTORS.clear();
    }
}
