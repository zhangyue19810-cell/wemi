package com.airshipcockpit.client.renderer;

import com.airshipcockpit.block.CockpitScreenBlock;
import com.airshipcockpit.blockentity.CockpitScreenBlockEntity;
import com.airshipcockpit.client.CockpitRenderHandler;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;
import org.joml.Matrix4f;

public class CockpitScreenRenderer implements BlockEntityRenderer<CockpitScreenBlockEntity> {

    public CockpitScreenRenderer(BlockEntityRendererProvider.Context ctx) {}

    // 1. 兼容 Iris 光影的【动态画面】渲染类型 (带纹理、光照)
    public static RenderType getIrisCompatibleType(ResourceLocation texture) {
        return RenderType.create(
            "cockpit_screen_iris",
            com.mojang.blaze3d.vertex.DefaultVertexFormat.POSITION_COLOR_TEX_LIGHTMAP,
            com.mojang.blaze3d.vertex.VertexFormat.Mode.QUADS,
            1536, false, true,
            RenderType.CompositeState.builder()
                .setShaderState(new net.minecraft.client.renderer.RenderStateShard.ShaderStateShard(net.minecraft.client.renderer.GameRenderer::getPositionColorTexLightmapShader))
                .setTextureState(new net.minecraft.client.renderer.RenderStateShard.TextureStateShard(texture, false, false))
                .setTransparencyState(net.minecraft.client.renderer.RenderStateShard.TRANSLUCENT_TRANSPARENCY)
                .setLightmapState(net.minecraft.client.renderer.RenderStateShard.LIGHTMAP)
                .createCompositeState(false)
        );
    }

    // 2. 兼容 Iris 光影的【未激活纯色】渲染类型 (无纹理、纯色)
    public static RenderType getIrisCompatibleColorType() {
        return RenderType.create(
            "cockpit_screen_color_iris",
            com.mojang.blaze3d.vertex.DefaultVertexFormat.POSITION_COLOR,
            com.mojang.blaze3d.vertex.VertexFormat.Mode.QUADS,
            1536, false, true,
            RenderType.CompositeState.builder()
                .setShaderState(new net.minecraft.client.renderer.RenderStateShard.ShaderStateShard(net.minecraft.client.renderer.GameRenderer::getPositionColorShader))
                .setTransparencyState(net.minecraft.client.renderer.RenderStateShard.NO_TRANSPARENCY)
                .createCompositeState(false)
        );
    }

    @Override
    public void render(
            CockpitScreenBlockEntity be,
            float partialTick,
            PoseStack poseStack,
            MultiBufferSource bufferSource,
            int packedLight,
            int packedOverlay) {

        boolean active  = be.isActive();
        BlockPos detPos = be.getLinkedDetector();
        BlockState state = be.getBlockState();

        Direction facing = Direction.NORTH;
        if (state.hasProperty(CockpitScreenBlock.FACING)) {
            facing = state.getValue(CockpitScreenBlock.FACING);
        }

        poseStack.pushPose();
        poseStack.translate(0.5, 0.5, 0.5);
        poseStack.mulPose(Axis.YP.rotationDegrees(facingToRotation(facing)));
        poseStack.translate(-0.5, -0.5, -0.5);

        Matrix4f m = poseStack.last().pose();
        final float Z = 1.001f;

        if (!active) {
            colorQuad(bufferSource.getBuffer(getIrisCompatibleColorType()),
                m, 0f, 0f, 1f, 1f, Z, 0f, 0f, 0f, 1f);
            poseStack.popPose();
            return;
        }

        if (detPos == null) {
            colorQuad(bufferSource.getBuffer(getIrisCompatibleColorType()),
                m, 0f, 0f, 1f, 1f, Z, 0f, 1f, 0.1f, 1f);
            poseStack.popPose();
            return;
        }

        CockpitRenderHandler.setDetectorActive(detPos, true);
        ResourceLocation texLoc = CockpitRenderHandler.getTextureLocation(detPos);

        if (texLoc == null) {
            colorQuad(bufferSource.getBuffer(getIrisCompatibleColorType()),
                m, 0f, 0f, 1f, 1f, Z, 0f, 0.3f, 1f, 1f);
            poseStack.popPose();
            return;
        }

        // UV 分割
        float[] uv = be.getGroupUVOffsets(facing);
        float uMin = uv[0], uMax = uv[1];
        float vMin = uv[2];
        float vMax = uv[3];

        // 动态画面管线
        VertexConsumer tc = bufferSource.getBuffer(getIrisCompatibleType(texLoc));
        int lx = 0xF0, ly = 0xF0;
        
        // 【核心修复点】重调 UV 映射顺序，将画面水平+垂直同时翻转过来
        tc.addVertex(m, 0f, 0f, Z).setColor(255,255,255,255).setUv(uMax, vMax).setUv2(lx, ly);
        tc.addVertex(m, 1f, 0f, Z).setColor(255,255,255,255).setUv(uMin, vMax).setUv2(lx, ly);
        tc.addVertex(m, 1f, 1f, Z).setColor(255,255,255,255).setUv(uMin, vMin).setUv2(lx, ly);
        tc.addVertex(m, 0f, 1f, Z).setColor(255,255,255,255).setUv(uMax, vMin).setUv2(lx, ly);

        poseStack.popPose();
    }

    private float facingToRotation(Direction facing) {
        return switch (facing) {
            case SOUTH -> 0f;
            case NORTH -> 180f;
            case EAST  -> 90f;
            case WEST  -> 270f;
            default    -> 0f;
        };
    }

    private void colorQuad(VertexConsumer c, Matrix4f m,
            float x1, float y1, float x2, float y2, float z,
            float r, float g, float b, float a) {
        c.addVertex(m, x1, y1, z).setColor(r, g, b, a);
        c.addVertex(m, x2, y1, z).setColor(r, g, b, a);
        c.addVertex(m, x2, y2, z).setColor(r, g, b, a);
        c.addVertex(m, x1, y2, z).setColor(r, g, b, a);
    }
}

