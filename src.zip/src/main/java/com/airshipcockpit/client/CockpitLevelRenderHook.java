package com.airshipcockpit.client;

import com.airshipcockpit.AirshipCockpitMod;
import net.minecraft.core.BlockPos;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

@EventBusSubscriber(modid = AirshipCockpitMod.MODID, value = Dist.CLIENT)
public class CockpitLevelRenderHook {

    @SubscribeEvent
    public static void onRenderLevelStage(RenderLevelStageEvent event) {
    AirshipCockpitMod.LOGGER.info("HOOK CALLED");

        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_LEVEL) return;
        if (!CockpitRenderHandler.shouldRenderThisFrame()) return;

        for (BlockPos detectorPos : CockpitRenderHandler.getActiveDetectors()) {
            DetectorCameraRenderer.renderDetectorView(detectorPos, event.getLevelRenderer());
        }
    }
}
