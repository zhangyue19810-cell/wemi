package com.airshipcockpit.client;

import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.server.packs.resources.ResourceManager;

public class FBOBackedTexture extends AbstractTexture {

    public FBOBackedTexture(int glTextureId) {
        this.id = glTextureId;
    }

    public void updateId(int newId) {
        this.id = newId;
    }

    @Override
    public void load(ResourceManager manager) {}

    @Override
    public void close() {
        // RenderTarget 负责销毁，这里不处理
    }
}
