package com.airshipcockpit.client;

import com.airshipcockpit.AirshipCockpitMod;
import com.airshipcockpit.block.CockpitDetectorBlock;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.fml.ModList;
import org.joml.Matrix4f;

public class DetectorCameraRenderer {

    private static int logCount = 0;

    // 检测 Iris/Oculus 是否加载
    private static final boolean IRIS_LOADED = checkMod("oculus", "iris");
    // 检测 Voxy 是否加载
    private static final boolean VOXY_LOADED = checkMod("voxy");

    private static boolean checkMod(String... ids) {
        try {
            ModList ml = ModList.get();
            if (ml == null) return false;
            for (String id : ids) if (ml.isLoaded(id)) return true;
        } catch (Exception ignored) {}
        return false;
    }

    // 检测 Iris shader 是否激活（运行时检测，不是加载时）
    private static boolean isIrisShaderActive() {
        if (!IRIS_LOADED) return false;
        try {
            Class<?> apiClass = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
            Object api = apiClass.getMethod("getInstance").invoke(null);
            return (boolean) apiClass.getMethod("isShaderPackInUse").invoke(api);
        } catch (Exception e) { return false; }
    }

    public static void renderDetectorView(BlockPos detectorPos, LevelRenderer levelRenderer) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.gameRenderer == null) return;

        BlockState state = mc.level.getBlockState(detectorPos);
        if (!(state.getBlock() instanceof CockpitDetectorBlock)) return;
        Direction facing = state.getValue(CockpitDetectorBlock.FACING);

        TextureTarget fbo = CockpitRenderHandler.getOrCreateFBO(detectorPos);
        if (fbo == null) return;

        boolean shaderActive = isIrisShaderActive();

        if (logCount++ % 60 == 0)
            AirshipCockpitMod.LOGGER.info(
                "[DetectorCam] facing={} iris={} shaderActive={} voxy={}",
                facing, IRIS_LOADED, shaderActive, VOXY_LOADED);

        Camera cam = mc.gameRenderer.getMainCamera();
        Vec3 camPos = cam.getPosition();
        double dx = (detectorPos.getX() + 0.5) - camPos.x;
        double dy = (detectorPos.getY() + 0.5) - camPos.y;
        double dz = (detectorPos.getZ() + 0.5) - camPos.z;

        float yaw = switch (facing) {
            case NORTH -> 0f; case SOUTH -> 180f;
            case WEST  -> 90f; case EAST  -> 270f;
            default    -> 0f;
        };

        Matrix4f modelView = new Matrix4f()
            .rotateY((float) Math.toRadians(yaw))
            .rotateZ((float) Math.PI)
            .translate((float)-dx, (float)-dy, (float)-dz);

        float aspect = (float) mc.getWindow().getWidth() / mc.getWindow().getHeight();
        float fovDeg = (float)(double) mc.options.fov().get();
        Matrix4f projection = new Matrix4f().perspective(
            (float) Math.toRadians(fovDeg), aspect, 0.05f,
            mc.options.getEffectiveRenderDistance() * 16.0f);

        fbo.bindWrite(true);

        // 真实天空色（时间/天气感知）
        Vec3 skyColor = mc.level.getSkyColor(camPos, mc.getTimer().getRealtimeDeltaTicks());
        RenderSystem.clearColor((float)skyColor.x, (float)skyColor.y, (float)skyColor.z, 1.0f);
        RenderSystem.clear(16640, false);

        // 只在无光影时渲染几何天空（有光影时跳过避免NPE）
        if (!shaderActive) {
            try {
                levelRenderer.renderSky(modelView, projection,
                    mc.getTimer().getRealtimeDeltaTicks(), cam, false, () -> {});
            } catch (Exception e) {
                AirshipCockpitMod.LOGGER.warn("[DetectorCam] renderSky 跳过: {}", e.getMessage());
            }
        }

        // 渲染地形（Sodium 兼容）
        try {
            levelRenderer.renderSectionLayer(RenderType.solid(),
                camPos.x, camPos.y, camPos.z, modelView, projection);
            levelRenderer.renderSectionLayer(RenderType.cutoutMipped(),
                camPos.x, camPos.y, camPos.z, modelView, projection);
            levelRenderer.renderSectionLayer(RenderType.cutout(),
                camPos.x, camPos.y, camPos.z, modelView, projection);
            levelRenderer.renderSectionLayer(RenderType.translucent(),
                camPos.x, camPos.y, camPos.z, modelView, projection);
        } catch (Exception e) {
            AirshipCockpitMod.LOGGER.error("[DetectorCam] renderSection: {}", e.getMessage());
        }

        // 渲染 Voxy LOD（如果已加载）
        VoxyRenderer.renderVoxyLOD(levelRenderer, modelView, projection, camPos.x, camPos.y, camPos.z);

        mc.getMainRenderTarget().bindWrite(true);
        CockpitRenderHandler.syncFBOTexture(detectorPos);
    }
}
