package com.airshipcockpit.client;

import com.airshipcockpit.AirshipCockpitMod;
import me.cortex.voxy.client.core.IGetVoxyRenderSystem;
import me.cortex.voxy.client.core.VoxyRenderSystem;
import net.caffeinemc.mods.sodium.client.render.chunk.ChunkRenderMatrices;
import net.minecraft.client.renderer.LevelRenderer;
import net.neoforged.fml.ModList;
import org.joml.Matrix4f;

public class VoxyRenderer {

    public static final boolean VOXY_LOADED = checkMod("voxy");
    public static final boolean SODIUM_LOADED = checkMod("sodium");

    private static boolean checkMod(String id) {
        try {
            ModList ml = ModList.get();
            return ml != null && ml.isLoaded(id);
        } catch (Exception e) { return false; }
    }

    public static void renderVoxyLOD(
            LevelRenderer levelRenderer,
            Matrix4f modelView,
            Matrix4f projection,
            double camX, double camY, double camZ) {

        if (!VOXY_LOADED || !SODIUM_LOADED) return;

        try {
            // 通过 Voxy 注入的接口获取 VoxyRenderSystem
            IGetVoxyRenderSystem iVoxy = (IGetVoxyRenderSystem) levelRenderer;
            VoxyRenderSystem vrs = iVoxy.voxy$getRenderSystem();
            if (vrs == null) {
                AirshipCockpitMod.LOGGER.warn("[Voxy] RenderSystem 为 null，跳过 LOD 渲染");
                return;
            }

            // 构建 Sodium 的 ChunkRenderMatrices
            ChunkRenderMatrices matrices = new ChunkRenderMatrices(
                projection,   // 投影矩阵
                modelView     // 模型视图矩阵
            );

            // 让 Voxy 用检测器视角渲染 LOD
            var viewport = vrs.setupViewport(matrices, camX, camY, camZ);
            vrs.renderOpaque(viewport);

            AirshipCockpitMod.LOGGER.debug("[Voxy] LOD 渲染完成");

        } catch (Exception e) {
            AirshipCockpitMod.LOGGER.warn("[Voxy] LOD 渲染失败: {}", e.getMessage());
        }
    }
}
