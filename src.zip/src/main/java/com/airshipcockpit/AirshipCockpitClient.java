package com.airshipcockpit;

import com.airshipcockpit.client.renderer.CockpitScreenRenderer;
import com.airshipcockpit.registry.ModBlockEntities;

import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;

@Mod(value = AirshipCockpitMod.MODID, dist = Dist.CLIENT)
@EventBusSubscriber(modid = AirshipCockpitMod.MODID, value = Dist.CLIENT)
public class AirshipCockpitClient {

    public AirshipCockpitClient(ModContainer container) {
        container.registerExtensionPoint(IConfigScreenFactory.class, ConfigurationScreen::new);
    }

    @SubscribeEvent
    static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(
            ModBlockEntities.COCKPIT_SCREEN.get(),
            CockpitScreenRenderer::new
        );
        AirshipCockpitMod.LOGGER.info("[AirshipCockpit] CockpitScreenRenderer 已注册");
    }

    @SubscribeEvent
    static void onClientSetup(FMLClientSetupEvent event) {
        AirshipCockpitMod.LOGGER.info("HELLO FROM CLIENT SETUP");
        AirshipCockpitMod.LOGGER.info("MINECRAFT NAME >> {}", Minecraft.getInstance().getUser().getName());
    }
}
