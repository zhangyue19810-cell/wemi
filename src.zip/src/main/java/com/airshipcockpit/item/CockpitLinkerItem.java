package com.airshipcockpit.item;

import com.airshipcockpit.blockentity.CockpitScreenBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.item.component.CustomData;

import java.util.List;

public class CockpitLinkerItem extends Item {

    public CockpitLinkerItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }

        Player player = context.getPlayer();
        if (player == null) return InteractionResult.PASS;

        BlockPos pos = context.getClickedPos();
        ItemStack stack = context.getItemInHand();
        BlockEntity be = level.getBlockEntity(pos);

        // 1.21+ 获取自定义 NBT 数据组件的方法
        CustomData customData = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY);
        CompoundTag tag = customData.copyTag();

        boolean isLinkingDetector = tag.getBoolean("LinkMode"); 

        // 1. Shift + 右键：切换工作模式
        if (player.isShiftKeyDown()) {
            isLinkingDetector = !isLinkingDetector;
            tag.putBoolean("LinkMode", isLinkingDetector);
            
            // 将更新后的 NBT 写回 1.21 的数据组件中
            stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
            
            String modeName = isLinkingDetector ? "§b外部检测器 (Camera)" : "§a控制台 (Controller)";
            player.displayClientMessage(Component.literal("§e[链路同步器] 模式切换: " + modeName), true);
            return InteractionResult.SUCCESS;
        }

        // 2. 右键点击的是屏幕方块：将坐标写入
        if (be instanceof CockpitScreenBlockEntity screen) {
            if (tag.contains("SavedX")) {
                BlockPos savedPos = new BlockPos(tag.getInt("SavedX"), tag.getInt("SavedY"), tag.getInt("SavedZ"));
                
                if (isLinkingDetector) {
                    screen.setLinkedDetector(savedPos);
                    player.displayClientMessage(Component.literal("§a[成功] 已将该屏幕链接至外部检测器: " + savedPos.toShortString()), true);
                } else {
                    screen.setControllerPos(savedPos);
                    player.displayClientMessage(Component.literal("§a[成功] 已将该屏幕方向基准设为控制台: " + savedPos.toShortString()), true);
                }
            } else {
                player.displayClientMessage(Component.literal("§c[错误] 工具内存为空！请先右键点击控制台或检测器记录坐标。"), true);
            }
        } 
        // 3. 右键点击其他普通方块：记录坐标
        else {
            tag.putInt("SavedX", pos.getX());
            tag.putInt("SavedY", pos.getY());
            tag.putInt("SavedZ", pos.getZ());
            
            // 写回组件
            stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
            
            String modeName = isLinkingDetector ? "§b外部检测器" : "§a控制台";
            player.displayClientMessage(Component.literal("§a[坐标已记录] 位置: " + pos.toShortString() + " (准备写入至: " + modeName + ")"), true);
        }

        return InteractionResult.SUCCESS;
    }

    // 1.21 改进了 appendHoverText 的参数，移除了 Level，增加了 TooltipContext
    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        CustomData customData = stack.get(DataComponents.CUSTOM_DATA);
        CompoundTag tag = customData != null ? customData.copyTag() : new CompoundTag();

        boolean isLinkingDetector = tag.getBoolean("LinkMode");
        tooltip.add(Component.literal("§7当前模式: " + (isLinkingDetector ? "§b绑定外部检测器" : "§a绑定控制台(方向基准)")));
        
        if (tag.contains("SavedX")) {
            tooltip.add(Component.literal("§7已存坐标: " + tag.getInt("SavedX") + ", " + tag.getInt("SavedY") + ", " + tag.getInt("SavedZ")));
        } else {
            tooltip.add(Component.literal("§7已存坐标: 无"));
        }
        
        tooltip.add(Component.literal(" ")); 
        tooltip.add(Component.literal("§8[Shift + 右键方块] 切换模式"));
        tooltip.add(Component.literal("§8[右键目标方块] 记录坐标"));
        tooltip.add(Component.literal("§8[右键屏幕方块] 写入坐标"));
    }
}
